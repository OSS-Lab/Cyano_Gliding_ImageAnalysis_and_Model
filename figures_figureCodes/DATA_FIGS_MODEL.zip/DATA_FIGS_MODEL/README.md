# Short readme

Data for figures F3 of the main text and S6, S7B, S12, S13, S14, S15, S16
when not specified, the data in the files are to be plotted first column (on x axis) vs second column (on y axis)

F3_C_bottom.dat ->  3 columns: time, position and velocity (in this order) 
F3_C_centre.dat -> as F3_C_bottom.dat
F3_C_top.dat -> as F3_C_bottom.dat

F3_D_phase_plot_coord.dat -> 3 columns: k_omega, omega_max, M 
F3_D_phase_plot_num_rev.dat -> 3 columns: k_omega, omega_max, S 
F3_S1_hist_reversals_0.0.dat ->   panel A, blue bars 
F3_S1_hist_reversals_5.0.dat ->   panel B 
F3_S1_hist_reversals_15.0.dat ->   panel C 
F3_S1_hist_reversals_30.0.dat ->   panel D 
F3_S1_hist_stopsandgo_0.0.dat ->   panel A, orange bars 
F3_S1_hist_stopsandgo_5.0.dat ->   panel B 
F3_S1_hist_stopsandgo_15.0.dat ->   panel C 
F3_S1_hist_stopsandgo_30.0.dat ->   panel D 
F3_S2_hist_dwell_r_1.0.dat ->   panel A, blue bars 
F3_S2_hist_dwell_r_3.0.dat ->   panel B 
F3_S2_hist_dwell_r_5.0.dat ->   panel C 
F3_S2_hist_dwell_r_10.0.dat ->   panel D 
F3_S2_hist_dwell_r_15.0.dat ->   panel E 
F3_S2_hist_dwell_r_30.0.dat ->   panel F 
F3_S2_hist_dwell_r_1.0.dat ->   panel A, orange bars 
F3_S2_hist_dwell_r_3.0.dat ->   panel B 
F3_S2_hist_dwell_r_5.0.dat ->   panel C 
F3_S2_hist_dwell_r_10.0.dat ->   panel D 
F3_S2_hist_dwell_r_15.0.dat ->   panel E 
F3_S2_hist_dwell_r_30.0.dat ->   panel F 
F3_S3_A.dat    
F3_S3_B.dat   
F3_S3_C.dat  
F3_S4_B.csv 
F3_S5_avg_rev.dat -> 4 columns: omega_max, k_omega, reverse_time, reverse_time_error
F3_S5_avg_stop.dat -> 4 columns: omega_max, k_omega, stopping_time, stopping_time_error
F3_S6_data.dat -> 4 columns: N_f, omega_max, reversal_freq (panel A), stopping_freq (panel B)
F3_S7_data.dat -> 5 columns: N_f, rev_freq, error_rev_freq, median_velocity, error_median_velocity
